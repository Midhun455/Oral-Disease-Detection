# xray detection > 2024-02-21 8:43pm
https://universe.roboflow.com/aksa-shaji-elvxv/xray-detection-xy7tk

Provided by a Roboflow user
License: CC BY 4.0

